# Spring源码系列

> lecture：波哥

# 1.谈谈你对SpringBoot的理解

聊一下SpringBoot的作用。Spring的脚手架工具。简化开发的难度。从SpringBoot的发展过程。

# 2. 介绍下SpringBoot的工作原理

自动装配的原理 -- run方法 @SpringBootApplication注解 分别的作用已经怎么关联的

# 3.介绍下@Import注解的作用

@Import注解的三种使用方式： 1。实现ImportSelector 接口 2。实现 ImportBeanDefinitionRegistrar接口 3。没有实现任何接口

# 4 .SpringBoot中为什么用的DeferredImportSelector?

作用：延迟注入。目的是降低注入的复杂度。实现条件注解中要求的各种先后循序

# 5.SpringBoot和SpringMVC的关系

SpringBoot是一个脚手架工具。控制层框架默认使用的就是SpringMVC

# 6.SpringBoot和Tomcat的关系

SpringBoot默认内嵌了Tomcat。

# 7.SpringMVC的工作原理

需要把DispatcherServlet + 处理器适配器 处理器映射器 视图解析器 结合起来

# 8.SpringSecurity中是如何实现自定义认证的

https://cloud.fynote.com/share/d/HlVIVVZp

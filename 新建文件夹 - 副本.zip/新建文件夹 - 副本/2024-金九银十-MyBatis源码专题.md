# MyBatis源码面试题

> lecture：波哥



https://www.processon.com/view/link/66ec06394d5b2b30b91f84ea?cid=66eba96f4d5b2b30b91eb379

# 一、介绍下你对MyBatis源码的理解

![image.png](https://fynotefile.oss-cn-zhangjiakou.aliyuncs.com/fynote/fyfile/1462/1726737940043/7177ab528b004846ab60a0089e0a200f.png)

&emsp;&emsp;MyBatis是一款优秀的Java ORM框架，其核心是实现了对关系型数据库的操作，它的源码实现主要集中在以下几个方面：

1. 映射器解析

&emsp;&emsp;MyBatis采用了XML和注解两种方式来定义SQL语句和映射器。在源码中，主要通过XMLMapperBuilder和MapperAnnotationBuilder两个类来解析XML和注解，并将解析后的映射信息存储到Configuration对象中。

2. SQL语句执行

&emsp;&emsp;MyBatis执行SQL语句的核心是SqlSession接口，SqlSession通过调用Executor对象来执行SQL语句。在源码中，MyBatis提供了两个Executor实现类：SimpleExecutor和ReuseExecutor。SimpleExecutor每次执行都会创建一个新的Statement对象，而ReuseExecutor会重用已经创建的Statement对象，以提高执行效率。

3. 对象映射

&emsp;&emsp;MyBatis支持将查询结果映射成Java对象，并支持一对多、多对一、一对一和多对多等复杂映射关系。在源码中，主要通过ResultMap和ResultSetHandler两个类来实现对象映射功能。ResultMap用于定义映射关系，ResultSetHandler则用于将查询结果转换成Java对象。

4. 插件机制

&emsp;&emsp;MyBatis提供了插件机制，可以在SQL语句执行前后、结果集返回前等关键节点插入自定义的逻辑。在源码中，主要通过Interceptor和InterceptorChain两个类来实现插件机制。

...........

总的来说，MyBatis源码实现了对关系型数据库的操作，提供了灵活的映射方式和插件机制，使得开发人员可以更加方便地操作数据库，提高开发效率。

# 二、谈谈你对MyBatis中缓存的理解

&emsp;&emsp;MyBatis中的缓存可以分为**一级缓存**和**二级缓存**两种，它们都是为了提高查询效率而存在的。

&emsp;&emsp;一级缓存是指在同一个SqlSession中，如果执行了相同的SQL语句，则MyBatis会将查询结果缓存在内存中，下次查询时可以直接从缓存中获取，而不需要再次向数据库发送查询请求。一级缓存的作用域是SqlSession级别的，只对当前SqlSession有效。

&emsp;&emsp;二级缓存是指在不同的SqlSession中，如果执行了相同的SQL语句，则MyBatis会将查询结果缓存在内存中，下次查询时可以直接从缓存中获取，而不需要再次向数据库发送查询请求。二级缓存的作用域是Mapper级别的，即所有的SqlSession共享同一个Mapper的二级缓存。需要注意的是，如果查询结果中的数据被更新、删除或者插入，那么该二级缓存就会被清空。

&emsp;&emsp;在MyBatis中，缓存可以通过配置文件中的<cache>标签进行配置，可以配置缓存的类型、作用域、缓存大小等参数。同时，MyBatis也支持通过插件机制来自定义缓存实现，以满足不同的应用场景。

需要注意的是，缓存虽然可以提高查询效率，但是也可能会导致数据不一致的问题，因此需要在实际使用中进行合理的配置和使用。

# 三、现在都是分布式环境，MyBatis如何实现三级缓存？

&emsp;&emsp;MyBatis本身只实现了一级缓存和二级缓存，没有官方提供的三级缓存实现方式。不过，我们可以通过自定义插件来实现三级缓存，具体实现方式如下：

1. 自定义缓存类

我们可以通过实现Cache接口来自定义缓存类。在实现过程中，需要考虑缓存的实现方式、过期时间等因素。

2. 实现插件类

在插件类中，我们需要重写Interceptor接口的intercept方法，这个方法会在执行SQL语句时被调用。我们可以在这个方法中判断当前查询是否可以从缓存中获取，如果可以，则直接返回缓存中的结果；否则，执行数据库查询并将结果缓存起来。

3. 配置插件

&emsp;&emsp;最后，我们需要在MyBatis的配置文件中配置插件。配置方式与配置MyBatis自带的插件类似，只需要将自定义的插件类添加到<plugins>标签中即可。

&emsp;&emsp;需要注意的是，自定义的三级缓存实现需要考虑缓存的并发访问和清空等问题，同时还需要进行性能测试，以确保自定义的缓存实现能够提高查询效率。

# 四、谈谈你对日志模块的理解

&emsp;&emsp;MyBatis的日志模块是一个可插拔的模块，可以通过配置文件灵活地选择使用不同的日志框架，如Log4j、Logback、JDK Logging等。

&emsp;&emsp;在MyBatis中，日志模块的主要作用是记录执行的SQL语句、参数、返回值等信息，以便开发人员进行调试和性能优化。具体来说，MyBatis的日志模块可以记录以下信息：

1. 执行的SQL语句及参数值
2. SQL语句执行的时间和耗时
3. 执行的Mapper接口和方法
4. 执行的返回值类型和返回结果

MyBatis的日志模块包含以下几个组件：

1. Log接口：MyBatis定义的日志接口，定义了常用的日志方法，如debug、info、warn、error等。
2. LogFactory接口：MyBatis定义的日志工厂接口，用于获取Log实例。
3. LogFactoryImpl类：MyBatis默认的日志工厂实现类，根据配置文件中的logImpl属性，选择不同的日志框架实现。
4. LogAdapter类：MyBatis默认的日志适配器，用于将Log接口和具体的日志框架进行适配。
5. Log4jImpl、LogbackImpl等类：MyBatis对各种日志框架的适配实现类。
6. LogInterceptor类：MyBatis默认的日志拦截器，用于记录执行的SQL语句和参数值。

&emsp;&emsp;在MyBatis的配置文件中，可以通过设置<settings>标签下的logImpl属性来选择使用不同的日志框架。如果不设置logImpl属性，则默认使用LogFactoryImpl类选择的日志框架。

&emsp;&emsp;需要注意的是，在生产环境中，日志输出会对系统性能造成一定的影响，因此在使用日志时需要谨慎考虑。可以通过设置日志级别、控制日志输出等方式来减少对系统性能的影响。

# 五、谈谈你对SqlSessionFactory的理解

&emsp;&emsp;SqlSessionFactory是MyBatis中的一个关键接口，用于创建SqlSession对象，是MyBatis的核心组件之一。

&emsp;&emsp;SqlSessionFactory是通过SqlSessionFactoryBuilder创建的，SqlSessionFactoryBuilder会读取MyBatis的配置文件（mybatis-config.xml），并根据配置文件中的信息构建SqlSessionFactory对象。

&emsp;&emsp;SqlSessionFactory的主要作用是提供了创建SqlSession对象的方法，SqlSession对象是MyBatis中执行数据库操作的主要接口。SqlSession可以通过SqlSessionFactory的openSession方法创建，并且可以设置是否自动提交事务。SqlSession的生命周期应该在一个较小的范围内控制，避免长时间持有，以免占用数据库连接资源。

&emsp;&emsp;SqlSessionFactory可以被多个线程共享，应该保证SqlSessionFactory的单例，避免资源浪费。

&emsp;&emsp;除此之外，SqlSessionFactory还可以配置MyBatis的一些全局属性，如数据库连接池、缓存等，这些全局属性可以在整个应用程序中共享，从而提高应用程序的性能和可维护性。

总之，SqlSessionFactory是MyBatis中非常重要的一个接口，负责创建SqlSession对象和管理MyBatis全局属性的配置，使用SqlSessionFactory可以简化数据库操作的编写和管理，提高应用程序的性能和可维护性。

# 六、谈谈你对SqlSession的理解

&emsp;&emsp;MyBatis是一个优秀的持久层框架，而SqlSession则是MyBatis框架中最为核心的组件之一。SqlSession可以看做是对数据库操作的一次会话，每个会话中可以执行多次数据库操作。下面是对SqlSession的一些理解：

1. SqlSession的生命周期：SqlSession的生命周期是从它的创建到关闭。SqlSession的创建可以通过SqlSessionFactory来创建，一般情况下，我们在需要访问数据库的时候，就会创建一个SqlSession对象。当SqlSession对象不再使用时，应该将其关闭。
2. SqlSession的作用：SqlSession封装了对数据库的操作，包括数据的插入、更新、删除和查询等操作。通过SqlSession可以执行Mapper中定义的方法，并将执行结果返回给应用程序。SqlSession还提供了事务管理的支持。
3. SqlSession的管理：在MyBatis中，SqlSession的管理是由SqlSessionFactory来管理的。SqlSessionFactory可以通过配置文件或者Java代码来创建，每个应用程序通常只需要一个SqlSessionFactory实例，用于创建SqlSession对象。在应用程序中，SqlSession的管理一般由Spring框架或者自己手动管理。
4. SqlSession的线程安全性：SqlSession不是线程安全的，每个SqlSession实例都应该被单独使用，不能被多个线程共享。在多线程环境下，如果多个线程共用一个SqlSession对象，则可能会出现数据混乱的情况，因此需要保证每个线程都有自己的SqlSession实例。

&emsp;&emsp;总之，SqlSession是MyBatis框架中最为核心的组件之一，它封装了对数据库的操作，提供了事务管理的支持，并由SqlSessionFactory进行管理。使用SqlSession时需要注意其生命周期、线程安全性等问题。

# 七、谈谈你对MyBatis中的Executor的源码理解

&emsp;&emsp;MyBatis框架中的Executor是一个执行器，负责执行SQL语句，与数据库进行交互，并将执行结果返回给调用方。Executor是MyBatis中最为核心的组件之一，它的实现涉及到多种设计模式和技术，包括装饰器模式、代理模式、线程池等。

下面是我对Executor的源码理解：

1. Executor的实现类：MyBatis中默认提供了三个Executor的实现类，分别是SimpleExecutor、ReuseExecutor和BatchExecutor。SimpleExecutor是最简单的Executor实现，每次执行SQL语句都会创建一个新的Statement对象；ReuseExecutor会尝试重用Statement对象，避免多次创建Statement对象，提高执行效率；BatchExecutor则是批量执行SQL语句的Executor实现。
2. Executor的作用：Executor的主要作用是执行SQL语句，并将执行结果返回给调用方。在执行SQL语句之前，Executor会首先创建Statement对象，然后通过JDBC与数据库进行交互，将执行结果返回给MyBatis框架。Executor还负责缓存Statement对象，避免多次创建Statement对象，提高执行效率。
3. Executor的执行流程：Executor的执行流程可以概括为以下几个步骤：
   * 根据传入的MappedStatement对象创建StatementHandler对象。
   * 判断是否开启了二级缓存，如果开启了，则先从二级缓存中获取执行结果。
   * 判断是否需要刷新缓存，如果需要，则清空缓存。
   * 执行SQL语句，并将执行结果保存到缓存中。
   * 如果开启了二级缓存，则将执行结果保存到二级缓存中。
4. Executor的线程安全性：Executor是线程安全的，多个线程可以共用同一个Executor实例。在多线程环境下，Executor会使用线程池来管理多个线程的执行，避免线程竞争和线程创建销毁的开销。

总之，Executor是MyBatis框架中最为核心的组件之一，它的实现涉及到多种设计模式和技术。Executor负责执行SQL语句，并将执行结果返回给调用方。使用Executor时需要注意其实现类、执行流程、线程安全性等问题。

# 八、MyBatis中是如何对占位符进行赋值的？

&emsp;&emsp;在MyBatis中，占位符通常使用#{param}的形式表示，其中param是一个参数的名称。MyBatis在执行SQL语句时，会将这些占位符替换成实际的参数值。下面是MyBatis中对占位符进行赋值的实现原理：

1. 解析SQL语句：在执行SQL语句之前，MyBatis会先对SQL语句进行解析，将其中的占位符替换成特定的标记。这些标记包括问号标记（?）和井号标记（#）。
2. 创建ParameterHandler对象：MyBatis会根据SQL语句和参数类型创建ParameterHandler对象，该对象负责将参数值设置到SQL语句中的占位符中。
3. 设置参数值：在执行SQL语句之前，MyBatis会调用ParameterHandler对象的setParameters方法，将参数值设置到SQL语句中的占位符中。在设置参数值时，MyBatis会根据参数的类型和占位符的类型进行类型转换。如果占位符使用的是#号，MyBatis会将占位符替换成一个具有参数值的字符串；如果占位符使用的是问号，MyBatis会将占位符替换成一个占位符的索引号，并将参数值保存到一个内部数组中。
4. 执行SQL语句：在设置完参数值之后，MyBatis会将SQL语句发送给数据库执行，并将执行结果返回给调用方。

总之，在MyBatis中，对占位符进行赋值是通过ParameterHandler对象来完成的，它将参数值设置到SQL语句中的占位符中，最终执行SQL语句并将执行结果返回给调用方。在设置参数值时，MyBatis会进行类型转换，并根据占位符的类型进行不同的处理。

# 九、Spring中是如何解决MyBatis的SqlSession的线程安全问题的？

Spring提供了两种解决方案来解决SqlSession的线程安全问题：

1.使用SqlSessionTemplate

SqlSessionTemplate是Spring提供的一个线程安全的SqlSession实现。它封装了SqlSession的操作，并确保每个线程都有自己的SqlSession实例。因此，在多线程环境下，每个线程都可以独立地使用自己的SqlSession实例，而不会相互干扰。可以在配置文件中定义SqlSessionTemplate bean，然后在需要使用SqlSession时注入该bean。

2.使用@Scope注解

另一个解决方案是在配置文件中使用@Scope注解，将SqlSession的作用域设置为prototype。这将确保每次从容器中获取SqlSession时都会返回一个新的实例，因此每个线程都可以使用自己的SqlSession实例。可以在配置文件中声明SqlSession bean，并使用@Scope注解将其作用域设置为prototype。在需要使用SqlSession时，可以注入该bean。

这两种解决方案都可以有效地解决SqlSession的线程安全问题。选择哪种方案取决于具体的需求和实现细节。

# 十、聊聊你对MyBatis中的Configuration的源码的理解

Configuration类的源码主要涉及以下几个方面：

1.加载配置文件

&emsp;&emsp;在MyBatis的配置文件中，可以配置数据源、映射文件、插件、类型别名等信息。Configuration通过XMLConfigBuilder类来加载配置文件，并将解析后的配置信息保存到Configuration对象中。

2.创建SqlSessionFactory

&emsp;&emsp;Configuration类也负责创建SqlSessionFactory。它会通过build方法创建SqlSessionFactory对象，并将该对象缓存起来，以便后续使用。在创建SqlSessionFactory对象时，会将Configuration对象作为参数传入，以便SqlSessionFactory可以获取MyBatis的配置信息和映射信息。

3.管理映射信息

&emsp;&emsp;MyBatis中的映射文件通常包含SQL语句和实体类之间的映射关系。Configuration会读取映射文件，将其中的SQL语句解析成MappedStatement对象，并将其保存到mappedStatements集合中。mappedStatements集合中保存了所有映射文件中定义的SQL语句，以及它们对应的MappedStatement对象。

4.管理缓存

&emsp;&emsp;Configuration还负责管理MyBatis的缓存。它会读取配置文件中的缓存配置信息，并创建对应的缓存对象，缓存对象被保存在caches集合中。在执行SQL语句时，如果该语句对应的MappedStatement对象中配置了缓存，则会从caches集合中获取缓存对象，并使用缓存对象来提高查询效率。

总的来说，Configuration类是MyBatis框架的核心组成部分之一，它负责加载配置文件、管理映射信息和缓存等功能，是整个框架的配置和管理中心。通过深入理解Configuration的源码，我们可以更好地理解MyBatis框架的原理和实现机制。

# 十一、谈谈MyBatis中的插件原理

&emsp;MyBatis插件是MyBatis提供的一个非常强大的拦截器机制，可以在MyBatis执行SQL语句的过程中，动态地修改SQL语句、统计SQL执行时间等。MyBatis插件的原理主要涉及以下几个方面：

1. 插件接口

&emsp;&emsp;MyBatis插件是基于Java的动态代理机制实现的，需要实现MyBatis提供的Interceptor接口。Interceptor接口中定义了3个方法：intercept、plugin和setProperties，其中intercept方法是最重要的，用于拦截MyBatis执行SQL语句的过程。

2. 插件拦截器链

&emsp;&emsp;MyBatis使用一个拦截器链来维护插件的执行顺序。在创建SqlSessionFactory对象时，会对所有配置的插件进行排序，并将它们依次加入到拦截器链中。在执行SQL语句时，MyBatis会按照拦截器链中的顺序依次调用插件的intercept方法，实现对SQL语句的拦截和修改。

3. 插件的配置

&emsp;&emsp;在MyBatis的配置文件中，可以通过<plugins>标签来配置插件。在<plugins>标签下面可以配置多个<plugin>标签，每个<plugin>标签都需要指定插件的实现类。同时，我们还可以在<plugin>标签中配置插件的属性，例如下面的示例：

```xml
<plugins>
  <plugin interceptor="com.example.plugin.MyPlugin">
    <property name="property1" value="value1"/>
    <property name="property2" value="value2"/>
  </plugin>
</plugins>
```

&emsp;&emsp;这里的MyPlugin是插件的实现类，同时还指定了两个属性：property1和property2。在插件的实现类中，可以通过setProperties方法获取这些属性值，以便在intercept方法中使用。

&emsp;&emsp;总的来说，MyBatis插件机制是MyBatis框架中的一个非常强大的拓展点，通过实现Interceptor接口，可以方便地拦截和修改SQL语句的执行过程。通过深入理解MyBatis插件的原理，我们可以更好地掌握MyBatis的核心功能。
